import { Link, useNavigate } from 'react-router-dom'

function SideBar() {
  const role = sessionStorage.getItem('role')
  console.log('Role ', role)
  const navigate = useNavigate()
  const logout = () => {
    sessionStorage.clear()
    navigate('/')
  }
  const isstaff = role === 'Staff'
  const ismember = role === 'Member'
  return (
    <div className='list-group list-group-flush'>
      {isstaff ? (
        <>
          <Link
            to='/uhome'
            className='list-group-item list-group-item-action p-2 text-left'
          >
            Profile
          </Link>
          <Link
            to='/members'
            className='list-group-item list-group-item-action p-2 text-left'
          >
            Members
          </Link>
          <Link
            to='/books'
            className='list-group-item list-group-item-action p-2 text-left'
          >
            Books
          </Link>
          <button
            onClick={e=>logout()}
            className='list-group-item list-group-item-action p-2 text-left'
          >
            Logout
          </button>
        </>
      ) : null}

      {ismember ? (
        <>
          <Link
            to='/uhome'
            className='list-group-item list-group-item-action p-2 text-left'
          >
            Profile
          </Link>
          <Link
            to='/issued'
            className='list-group-item list-group-item-action p-2 text-left'
          >
            Issued Books
          </Link>          
          <button
            onClick={e=>logout()}
            className='list-group-item list-group-item-action p-2 text-left'
          >
            Logout
          </button>
        </>
      ) : null}
    </div>
  )
}

export default SideBar
