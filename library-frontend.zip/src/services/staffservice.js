import axios from "axios";
const BASE_URL="http://localhost:8080/api/staffs"
const token=sessionStorage.getItem('token')
class StaffService {
    getStaffs(){
        return axios.get(BASE_URL,{
            headers: {
              Authorization: 'Bearer ' + token,        
            }
        })
    }

    register(data){
        return axios.post(BASE_URL,data)
    }

    getStaffDetails(id){
        return axios.get(BASE_URL+'/'+id,{
            headers: {
              Authorization: 'Bearer ' + token,        
            }
        })
    }
}

export default new StaffService()