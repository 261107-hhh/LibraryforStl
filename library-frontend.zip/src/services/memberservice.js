import axios from "axios"
const BASE_URL="http://localhost:8080/api/members"
const token=sessionStorage.getItem('token')
class MemberService{
    register(data){
        return axios.post(BASE_URL,data)
    }

    allMembers(){
        return axios.get(BASE_URL,{
            headers: {
              Authorization: 'Bearer ' + token,        
            }
        })
    }

    getMemberDetails(id){
        return axios.get(BASE_URL+'/'+id,{
            headers: {
              Authorization: 'Bearer ' + token,        
            }
        })
    }
}

export default new MemberService()