import axios from "axios";
const BASE_URL="http://localhost:8080/api/books"
const token=sessionStorage.getItem('token')
class BookService {
    getBooks(){
        return axios.get(BASE_URL,{
            headers: {
              Authorization: 'Bearer ' + token,        
            }
        })
    }

    addBook(data){
        return axios.post(BASE_URL,data,{
            headers: {
              Authorization: 'Bearer ' + token,        
            }
        })
    }

    updateBook(id,data){
        return axios.put(BASE_URL+'/'+id,data,{
            headers: {
              Authorization: 'Bearer ' + token,        
            }
        })
    }

    getBookDetails(id){
        return axios.get(BASE_URL+'/'+id,{
            headers: {
              Authorization: 'Bearer ' + token,        
            }
        })
    }

    history(id){
        return axios.get(BASE_URL+'/history/'+id,{
            headers: {
              Authorization: 'Bearer ' + token,        
            }
        })
    }
    memberHistory(id){
        return axios.get(BASE_URL+'/member/'+id,{
            headers: {
              Authorization: 'Bearer ' + token,        
            }
        })
    }

    issueBook(data){
        return axios.post(BASE_URL+'/issue',data,{
            headers: {
              Authorization: 'Bearer ' + token,        
            }
        })
    }
    
    returnBook(data){
        return axios.post(BASE_URL+'/return',data,{
            headers: {
              Authorization: 'Bearer ' + token,        
            }
        })
    }
}

export default new BookService()