import { useEffect, useState } from "react";
import Header from "../components/Header";
import SideBar from "../components/SideBar";
import bookservice from "../services/bookservice";

function IssuedBooks() {
    const [book,setBooks]=useState([])
    useEffect(()=>{
        bookservice.memberHistory(sessionStorage.getItem('id'))
        .then(resp=>setBooks(resp.data.data))
    },[])
  return (
    <>
    <Header />
      <div className='container-fluid'>
        <div className='row'>
          <div
            className='col-sm-2 bg-transparent p-0 border-right border-primary'
            style={{ height: 'calc(100vh - 80px)' }}
          >
            <SideBar />
          </div>
          <div className='col-sm-10 p-3'>
        <h4 className="text-center mb-2 border-bottom pb-2">Issued Books History</h4>
        <table className="table table-sm table-bordered table-fixed">
          <thead className="table-dark">
            <tr style={{ position: "sticky", top: 0 }}>
              <th>Date</th>
              <th>Book ID</th>
              <th>Book Name </th>
              <th>Author</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody style={{ overflow: "scroll" }}>
            {book.map(x=>(
            <tr key={x.id}>
              <td>{x.trandate}</td>
              <td>{x.book.id}</td>
              <td>{x.book.title}</td>
              <td>{x.book.author}</td>
              <td>{x.isreturned ? 'Returned':'Issued'}</td>
            </tr>
            ))}
          </tbody>
        </table>
      </div>
      </div>
      </div>
    </>
  );
}
export  default IssuedBooks