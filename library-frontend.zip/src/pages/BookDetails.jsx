import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import Header from "../components/Header";
import SideBar from "../components/SideBar";
import bookservice from "../services/bookservice";
import memberservice from "../services/memberservice";

function BookDetails() {
  const { id } = useParams();
  const [book, setBook] = useState();
  const [memberid, setMemberid] = useState(0);
  const [member,setMember]=useState()
  const navigate=useNavigate()
  const [history,setHistory]=useState([])
  const [imember,setImember]=useState()

  const searchMember = () => {
    memberservice
      .getMemberDetails(memberid)
      .then((resp) => {
        console.log(resp.data.data);
        if (resp.data.data) {
          setMember(resp.data.data)
        } else {
          setMember(null)
          alert('Invalid member id')
        }
      })
      .catch((error) => {
        console.error(error);
      });
  };

  const issueBook=()=>{
    bookservice.issueBook({bookid:id,stdid:memberid,issuerid:sessionStorage.getItem('id')})
    .then(resp=>
        {
            console.log(resp.data.data)
            alert(resp.data.data)
            navigate('/books')
        })
    .catch(error=>console.error(error))
  }

  const returnBook=()=>{
    bookservice.returnBook({bookid:id,stdid:imember.id})
    .then(resp=>{
        alert(resp.data.data)
        navigate('/books')
    })
    .catch(error=>{
        console.log(error)
    })
  }

  useEffect(() => {
    bookservice.getBookDetails(id).then((resp) => {
      setBook(resp.data.data);
    });

    bookservice.history(id).then(resp=>
        {
            setHistory(resp.data.data)
            if(resp.data.data.length>0 &&  !book?.available){
                setImember(resp.data.data[0].member)
            }
        })
  }, []);
  return (
    <>
      <Header />
      <div className="container-fluid">
        <div className="row">
          <div
            className="col-sm-2 bg-transparent p-0 border-right border-primary"
            style={{ height: "calc(100vh - 80px)" }}
          >
            <SideBar />
          </div>
          <div className="col-sm-10">
            <div className="row">
              <div className="col-sm-4">
                <div className="card shadow mt-2">
                  <div className="card-header">
                    <h5>Book Details</h5>
                  </div>
                  <div className="card-body">
                    <h6>Name: {book?.title}</h6>
                    <h6>Author: {book?.author}</h6>
                    <h6>Subject: {book?.subject}</h6>
                    <h6>Price: Rs.{book?.price}</h6>
                    <h6>Description: {book?.description}</h6>
                    <h6>
                      Status: {book?.available ? "Available" : "Not available"}
                    </h6>
                  </div>
                </div>
              </div>
              <div className="col-sm-4">
                {book?.available ? (
                  <div className="card shadow mt-2">
                    <div className="card-header">
                      <h5>Book Issue Panel</h5>
                    </div>
                    <div className="card-body">
                      <div class="input-group mb-3">
                        <input
                          type="number"
                          min="1"
                          onChange={(e) => setMemberid(e.target.value)}
                          class="form-control form-control-sm"
                          placeholder="Enter memberid to Search"
                        />
                        <div class="input-group-append">
                          <button
                            class="btn btn-success btn-sm"
                            onClick={(e) => searchMember()}
                          >
                            Search
                          </button>
                        </div>
                      </div>

                      {(member) ? (
                        <>
                        <h6>Member Found : {member?.name}</h6>
                        <button className="btn btn-success btn-sm" onClick={e=>issueBook()}>Issue Book</button>
                        </>
                      ):null}
                      
                    </div>
                  </div>
                ) : (
                  <div className="card shadow mt-2">
                    <div className="card-header">
                      <h5>Book Return Panel</h5>
                    </div>
                    <div className="card-body">
                        Book was issue to {imember?.name}<br/>
                        <button className="btn btn-primary btn-sm" onClick={e=>returnBook()}>Return Book</button>
                    </div>
                  </div>
                )}
              </div>
              <div className="col-sm-4">
                <div className="card shadow mt-2">
                  <div className="card-header">
                    <h5>Book History</h5>
                  </div>
                  <div className="card-body">
                    <table className="table table-bordered table-sm">
                      <thead>
                        <tr>
                          <th>Date</th>
                          <th>Description</th>
                          <th>Member</th>
                        </tr>
                      </thead>
                      <tbody>
                        {history.map(x=>(
                            <tr key={x.id}>
                                <td>{x.trandate}</td>
                                <td>{x.isissued ? 'Issued':'Returned'}</td>
                                <td>{x.member.name}</td>
                            </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default BookDetails;
