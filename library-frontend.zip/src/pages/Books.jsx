import { useEffect, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import Header from '../components/Header'
import SideBar from '../components/SideBar'
import bookservice from '../services/bookservice'

function Books() {
  const [Books, setBooks] = useState([])
  const [search,setSearch]=useState()
  const [data,setData]=useState([])
  const token = sessionStorage.getItem('token')
  const navigate=useNavigate()
  const loadData = () => {
    console.log('Token ', token)
    bookservice.getBooks().then((resp) => {
      setBooks(resp.data.data)
      setData(resp.data.data)
      console.log(Books)
    })
  }

  
  useEffect(() => {
    const result=Books.filter(x=>x.id==search.trim() || x.title.toLowerCase().includes(search.toLowerCase()) || x.subject.toLowerCase().includes(search.toLowerCase()) || x.author.toLowerCase().includes(search.toLowerCase()))
    console.log(result)
    setData(result)
  }, [search])

  useEffect(() => {
    loadData()
  }, [])

  return (
    <>
      <Header />
      <div className='container-fluid'>
        <div className='row'>
          <div
            className='col-sm-2 bg-transparent p-0 border-right border-primary'
            style={{ height: 'calc(100vh - 80px)' }}
          >
            <SideBar />
          </div>
          <div className='col-sm-10'>
            <div className='float-right' style={{width:"500px"}}>
          <input type="text" name="search" onChange={e=>setSearch(e.target.value)} placeholder="Enter book code or title or author or subject to search" className="form-control form-control-sm mt-2 mr-2 d-inline-block" style={{width:"399px"}}/>
          <Link to="/addbook" className="btn btn-primary btn-sm">Add New</Link>
          </div>
            <h4 className='text-left p-2 border-bottom border-success'>
              All Books
            </h4>
            <table className='table table-sm table-bordered table-striped table-hover'>
              <thead>
                <tr>
                  <th>Access Code</th>
                  <th>Book Title</th>
                  <th>Author</th>
                  <th>Price</th>
                  <th>Subject</th>
                  <th>Description</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {data.map((x) => (
                  <tr key={x.id}>
                    <td>{x.id}</td>
                    <td>{x.title}</td>
                    <td>{x.author}</td>
                    <td>Rs.{x.price}</td>
                    <td>{x.subject}</td>
                    <td>{x.description}</td>
                    <td>{x.available ? 'Available': 'Issued'}</td>
                    <td>
                      <button className='btn btn-sm btn-primary mr-2' onClick={e=>navigate('/editbook/'+x.id)}>Edit</button>
                      <button className='btn btn-sm btn-success' onClick={e=>navigate('/books/'+x.id)}>Details</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </>
  )
}

export default Books
