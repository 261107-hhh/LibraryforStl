import { Link, useNavigate } from 'react-router-dom'

function HomePage() {
  const navigate = useNavigate()
  return (
    <div className='body'>
      <div className="jumbotron bg-transparent p-4 text-center shadow">
            <h3>Library System</h3>    
        </div>
        <div className="container">
            <div className="row">
                <div className="col-9 mx-auto text-center">
                    <Link to="/login">
                    <div className="d-inline-block border border-dark p-2 card shadow" style={{width:"260px"}}>
	                    <div className="card-body">
	                        <img src="images/liblogo.png" className="img-thumbnail" style={{height:"200px",width:"200px"}}/>
	                    </div>
	                    <div className="card-footer">
	                        <h5>Login Library</h5>
	                    </div>
                    </div>
                    </Link>
                    <Link to="/register">`
                    <div className="d-inline-block border border-dark p-2 card shadow" style={{width:"260px"}}>
                    <div className="card-body">
                        <img src="images/customer.png" className="img-thumbnail" style={{height:"200px",width:"200px"}}/>
                    </div>
                    <div className="card-footer">
                        <h5>Registrations</h5>
                    </div>
                    </div>
                    </Link>                     
                </div>
            </div>
        </div>
    </div>
  )
}
export default HomePage
