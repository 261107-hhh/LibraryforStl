import { Link } from "react-router-dom";
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import membervalidation from "../validation/membervalidation";
import memberservice from "../services/memberservice";
import staffservice from "../services/staffservice";

function RegisterPage(){
    const [member, setMember] = useState(null)
    const [errors, setErrors] = useState({})
    const navigate = useNavigate()

    const handleInput = (e) => {
        setMember({ ...member, [e.target.name]: e.target.value })
    }

    const handleStaffSubmit=e=>{
        e.preventDefault()
        setErrors(membervalidation(member))

        if (Object.keys(errors).length === 0) {
        console.log(member)
        staffservice
            .register(member)
            .then((resp) => {
            console.log(resp.data)
            alert('Staff registered successfully userid '+resp.data.data)     
            navigate('/login')       
            })
            .catch((error) => console.log('Error', error))
        }
    }

    const handleSubmit = (e) => {
        e.preventDefault()
        setErrors(membervalidation(member))

        if (Object.keys(errors).length === 0) {
        console.log(member)
        memberservice
            .register(member)
            .then((resp) => {
            console.log(resp)
            alert('Member registered successfully with id'+resp.data.data)  
            navigate('/login')          
            })
            .catch((error) => console.log('Error', error))
        }
    }

    return (
        <>
        <Link to="/" className="btn btn-sm btn-primary float-right m-2">Home</Link>
        <div className="jumbotron text-white p-4" style={{backgroundColor: "#0000005c"}}>
            <h2 className="text-center">Registration Screen</h2>
        </div>
        <div className="container">
            <div className="row">
                <div className="col-sm-5">
                <div className="card shadow">
                	<div className="card-header text-center">
                		<h5>Staff Registration</h5>
                	</div>
                	<div className="card-body">
                    <form onSubmit={handleStaffSubmit}>
                        <div className="form-group form-row">                        
                            <label className="col-sm-4 col-form-label">Name</label>
                            <div className="col-sm-8">
                            <input type="text" name="name" required className="form-control"
                                   onChange={handleInput} placeholder="Name"/>
                            </div>
                        </div>
                        <div className="form-group form-row">                        
                            <label className="col-sm-4 col-form-label">City</label>
                            <div className="col-sm-8">
                            <input type="text" name="city" required className="form-control"
                                   onChange={handleInput} placeholder="City"/>
                        </div>
                        </div>
						<div className="form-group form-row">                        
                            <label className="col-sm-4 col-form-label">Phone</label>
                            <div className="col-sm-8">
                            <input type="text" name="phone" maxlength="10" required className="form-control"
                                   onChange={handleInput} placeholder="Contact Number"/>
                        </div>
                        </div>
						<div className="form-group form-row">                        
                            <label className="col-sm-4 col-form-label">Email Id</label>
                            <div className="col-sm-8">
                            <input type="email" name="email" required className="form-control"
                                    onChange={handleInput}placeholder="Email Address"/>
                        </div>
                        </div>
                        
                        <div className="form-group form-row">                        
                            <label className="col-sm-4 col-form-label">Gender</label>
                            <div className="col-sm-8">
                            <select name="gender" onChange={handleInput} required className="form-control">	
                            	<option value="">Select Gender</option>
                            	<option>Male</option>
                            	<option>Female</option>
                            </select>
                        </div>
                        </div>

                       <div className="form-group form-row">                        
                            <label className="col-sm-4 col-form-label">Password</label>
                            <div className="col-sm-8">
                            <input type="password" onChange={handleInput} name="pwd" required className="form-control"
                                   placeholder="Password"/>
                        </div>
                        </div>
                        <input type="submit" value="Register" className="btn btn-primary float-right px-3"/>
                    </form>
                	</div>
                </div>
                                
                </div>
                
                <div className="col-sm-6 offset-1">
                <div className="card shadow">
                <div className="card-header text-center">
                	<h5>Member Registration</h5>
                </div>
                	<div className="card-body">                	
                	<form onSubmit={handleSubmit}>
                        <div className="form-group form-row">                        
                            <label className="col-sm-4 col-form-label">Name</label>
                            <div className="col-sm-8">
                            <input type="text" name="name" required className="form-control"
                                   onChange={handleInput} placeholder="Name"/>
                            </div>
                        </div>
                        <div className="form-group form-row">                        
                            <label className="col-sm-4 col-form-label">City</label>
                            <div className="col-sm-8">
                            <input type="text" name="city" required className="form-control"
                                   onChange={handleInput} placeholder="City"/>
                        </div>
                        </div>
						<div className="form-group form-row">                        
                            <label className="col-sm-4 col-form-label">Phone</label>
                            <div className="col-sm-8">
                            <input type="text" name="phone" maxlength="10" required className="form-control"
                                   onChange={handleInput} placeholder="Contact Number"/>
                        </div>
                        </div>
						<div className="form-group form-row">                        
                            <label className="col-sm-4 col-form-label">Email Id</label>
                            <div className="col-sm-8">
                            <input type="email" name="email" required className="form-control"
                                    onChange={handleInput}placeholder="Email Address"/>
                        </div>
                        </div>
                        
                        <div className="form-group form-row">                        
                            <label className="col-sm-4 col-form-label">Gender</label>
                            <div className="col-sm-8">
                            <select name="gender" onChange={handleInput} required className="form-control">	
                            	<option value="">Select Gender</option>
                            	<option>Male</option>
                            	<option>Female</option>
                            </select>
                        </div>
                        </div>

                       <div className="form-group form-row">                        
                            <label className="col-sm-4 col-form-label">Password</label>
                            <div className="col-sm-8">
                            <input type="password" onChange={handleInput} name="pwd" required className="form-control"
                                   placeholder="Password"/>
                        </div>
                        </div>
                        <input type="submit" value="Register" className="btn btn-primary float-right px-3"/>
                    </form>
                	</div>
                </div>
                                
                </div>
            </div>
        </div> 
        </>
    )
}

export default RegisterPage;