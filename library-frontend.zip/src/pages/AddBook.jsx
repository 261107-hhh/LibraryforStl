import { useState } from "react";
import { useNavigate } from "react-router-dom";
import Header from "../components/Header";
import SideBar from "../components/SideBar";
import bookservice from "../services/bookservice";

function AddBook() {
    const [book, setBook] = useState();
    const navigate=useNavigate()
    const handleInput = (e) => {
        setBook({ ...book, [e.target.name]: e.target.value })
    }

    const handleSubmit = (e) => {
        e.preventDefault()
        bookservice.addBook(book).then(resp=>{
            alert('Book added successfully')
            navigate('/books')
        })
        .catch(error=>alert('Error occurrred'))
    };
    return (
    <>
    <Header />
      <div className='container-fluid'>
        <div className='row'>
          <div
            className='col-sm-2 bg-transparent p-0 border-right border-primary'
            style={{ height: 'calc(100vh - 80px)' }}
          >
            <SideBar />
          </div>
          <div className='col-sm-10'>
      <div className="row">
        <div className="col-sm-6 mx-auto">
          <h4 className="text-center mb-2 border-bottom pb-2">Add New Book</h4>
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label>Book Name</label>
              <input
                type="text"
                name="title"
                onChange={handleInput}
                className="form-control"
                placeholder="Book Name"
              />
            </div>
            <div className="form-group">
              <label>Book Author</label>
              <input
                type="text"
                name="author"
                onChange={handleInput}
                className="form-control"
                placeholder="Author Name"
              />
            </div>
            <div className="form-group">
              <label>Book Subject</label>
              <input
                type="text"
                name="subject"
                onChange={handleInput}
                className="form-control"
                placeholder="Publisher"
              />
            </div>
            <div className="form-group">
              <label>Book Price</label>
              <input
                type="text"
                name="price"
                onChange={handleInput}
                className="form-control"
                placeholder="Product Price"
              />
            </div>
            <div className="form-group">
              <label>Description</label>
              <textarea
                placeholder="Description"
                rows="4"
                onChange={handleInput}
                className="form-control"
                style={{resize: "none"}}
                name="description"
              ></textarea>
            </div>
            <input
              type="submit"
              value="Save Book"
              className="btn btn-primary float-right"
            />
          </form>
        </div>
      </div>
      </div>
      </div>
      </div>
    </>
  );
}

export default AddBook;
