import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import Header from "../components/Header";
import SideBar from "../components/SideBar";
import bookservice from "../services/bookservice";

function EditBook() {
  const { id } = useParams();
  const [book, setBook] = useState();
    const navigate=useNavigate()
    const handleInput = (e) => {
        setBook({ ...book, [e.target.name]: e.target.value })
    }
    useEffect(() => {
      bookservice.getBookDetails(id).then((resp) => {
        setBook(resp.data.data);
      });
    },[])

    const handleSubmit = (e) => {
        e.preventDefault()
        bookservice.updateBook(id,book).then(resp=>{
            alert('Book updated successfully')
            navigate('/books')
        })
        .catch(error=>alert('Error occurrred'))
    };
    return (
    <>
    <Header />
      <div className='container-fluid'>
        <div className='row'>
          <div
            className='col-sm-2 bg-transparent p-0 border-right border-primary'
            style={{ height: 'calc(100vh - 80px)' }}
          >
            <SideBar />
          </div>
          <div className='col-sm-10'>
      <div className="row">
        <div className="col-sm-6 mx-auto">
          <h4 className="text-center mb-2 border-bottom pb-2">Add New Book</h4>
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label>Book Name</label>
              <input
                type="text"
                name="title"
                value={book?.title}
                onChange={handleInput}
                className="form-control"
                placeholder="Book Name"
              />
            </div>
            <div className="form-group">
              <label>Book Author</label>
              <input
                type="text"
                name="author"
                value={book?.author}
                onChange={handleInput}
                className="form-control"
                placeholder="Author Name"
              />
            </div>
            <div className="form-group">
              <label>Book Subject</label>
              <input
                type="text"
                name="subject"
                value={book?.subject}
                onChange={handleInput}
                className="form-control"
                placeholder="Publisher"
              />
            </div>
            <div className="form-group">
              <label>Book Price</label>
              <input
                type="text"
                name="price"
                value={book?.price}
                onChange={handleInput}
                className="form-control"
                placeholder="Product Price"
              />
            </div>
            <div className="form-group">
              <label>Description</label>
              <textarea
                placeholder="Description"
                rows="4"
                value={book?.description}
                onChange={handleInput}
                className="form-control"
                style={{resize: "none"}}
                name="description"
              ></textarea>
            </div>
            <input
              type="submit"
              value="Save Book"
              className="btn btn-primary float-right"
            />
           
          </form>
        </div>
      </div>
      </div>
      </div>
      </div>
    </>
  );
}

export default EditBook;
