import './App.css';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import LoginPage from './pages/LoginPage';
import HomePage from './pages/home';
import ChangePassword from './pages/ChangePassword';
import PageNotFound from './pages/PageNotFound';
import UserHome from './pages/UserHome';
import RegisterPage from './pages/RegisterPage';
import Members from './pages/Members';
import Books from './pages/Books';
import AddBook from './pages/AddBook';
import BookDetails from './pages/BookDetails';
import IssuedBooks from './pages/IssuedBooks';
import EditBook from './pages/EditBook';

function App() {
  return (
    <div className="App">
      <BrowserRouter>      
        <Routes>
          <Route element={<HomePage />} path="/" exact />                    
          <Route element={<LoginPage />} path="/login" />
          <Route element={<RegisterPage />} path="/register" />
          <Route element={<Members />} path="/members" />
          <Route element={<Books />} path="/books" />
          <Route element={<AddBook />} path="/addbook" />
          <Route element={<EditBook />} path="/editbook/:id" />
          <Route element={<BookDetails />} path="/books/:id" />
          <Route element={<UserHome/>} path="/uhome"/>                                                            
          <Route element={<IssuedBooks/>} path="/issued"/>                                                            
          <Route element={<ChangePassword/>} path="/changepwd"/>
          <Route element={<PageNotFound />} path="*" />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
