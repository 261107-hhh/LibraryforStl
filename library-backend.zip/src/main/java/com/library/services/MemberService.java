package com.library.services;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.library.daos.MemberRepository;
import com.library.entities.Member;
import com.library.entities.User;
import com.library.models.MemberDTO;

@Service
public class MemberService {

	@Autowired private MemberRepository repo;
	@Autowired private UserService service;
	
	public String saveMember(MemberDTO dto) {
		Member member=new Member();
		BeanUtils.copyProperties(dto, member);
		member=repo.save(member);
		String userid=String.format("member%03d", member.getId());
		User user=new User();
		user.setPassword(dto.getPwd());
		user.setUserid(userid);
		user.setRole("Member");
		user.setUid(member.getId());
		user.setUname(dto.getName());
		service.registerUser(user);
		return userid;
	}
	
	public List<Member> listAll(){
		return repo.findAll();
	}
	
	public Member findById(int id) {
		return repo.findById(id).orElse(null);
	}
}
