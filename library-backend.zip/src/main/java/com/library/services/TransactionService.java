package com.library.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;

import com.library.daos.BookTransactionRepository;
import com.library.entities.Book;
import com.library.entities.BookTransaction;
import com.library.entities.Member;
import com.library.entities.Staff;
import com.library.models.TransactionDTO;

@Service
public class TransactionService {

	@Autowired private BookTransactionRepository repo;
	@Autowired private MemberService mservice;
	@Autowired private BookService bservice;
	@Autowired private StaffService sservice;
	
	public void issuebook(TransactionDTO dto) {
		Book book=bservice.findById(dto.getBookid());
		Member std=mservice.findById(dto.getStdid());
		Staff staff=sservice.findById(dto.getIssuerid());
		BookTransaction bt=new BookTransaction();
		bt.setBook(book);
		bt.setMember(std);
		bt.setIssuer(staff);
		bt.setIsissued(true);
		repo.save(bt);
		
		book.setAvailable(false);
		bservice.saveBook(book);
		
	}
	
	public void returnbook(TransactionDTO dto) {
		BookTransaction bt=repo.findByBookIdAndMemberId(dto.getBookid(),dto.getStdid());
		bt.setIsreturned(true);
		repo.save(bt);
		
		Book book=bservice.findById(dto.getBookid());
		book.setAvailable(true);
		bservice.saveBook(book);
		
	}
	
	public List<BookTransaction> memberHistory(int memberid){
		return repo.findByMemberIdOrderByIdDesc(memberid);
	}
	
	public List<BookTransaction> bookHistory(int bookid){
		return repo.findByBookIdOrderByIdDesc(bookid);
	}
	
	public List<BookTransaction> report(Optional<Integer> memid){
		if(memid.isPresent()) {
			return repo.findIssueBookTransactions(memid.get());
		}else {
			return repo.findAll(Sort.by(Direction.DESC,"id"));
		}
	}
	
	public List<Book> issuedBook(int memid){
		return repo.findIssueBook(memid);
	}
}
