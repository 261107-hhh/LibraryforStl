package com.library.services;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.library.daos.StaffRepository;
import com.library.entities.Staff;
import com.library.entities.User;
import com.library.models.StaffDTO;

@Service
public class StaffService {

	@Autowired private StaffRepository repo;
	@Autowired private UserService service;
	
	public String saveStaff(StaffDTO dto) {
		Staff member=new Staff();
		BeanUtils.copyProperties(dto, member);
		member=repo.save(member);
		String userid=String.format("staff%03d", member.getId());
		User user=new User();
		user.setPassword(dto.getPwd());
		user.setUserid(userid);
		user.setRole("Staff");
		user.setUid(member.getId());
		user.setUname(dto.getName());
		service.registerUser(user);
		return userid;
	}
	
	public Staff findById(int id) {
		return repo.findById(id).orElse(null);
	}
}
