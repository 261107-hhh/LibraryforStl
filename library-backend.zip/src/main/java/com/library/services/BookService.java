package com.library.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.library.daos.BookRepository;
import com.library.entities.Book;

@Service
public class BookService {

	@Autowired private BookRepository repo;
	
	public void saveBook(Book book) {
		repo.save(book);
	}
	
	public void updateBook(int id,Book book) {
		book.setId(id);
		repo.save(book);
	}
	
	public Book findById(int id) {
		return repo.findById(id).orElse(null);
	}
	
	public List<Book> listAll(){
		return repo.findAll();
	}
	
	public void deleteBook(int id) {
		repo.deleteById(id);
	}
}
