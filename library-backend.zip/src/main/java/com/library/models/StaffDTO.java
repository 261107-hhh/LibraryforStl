package com.library.models;

import com.library.entities.Staff;

public class StaffDTO extends Staff {
	private String pwd;

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	
}
