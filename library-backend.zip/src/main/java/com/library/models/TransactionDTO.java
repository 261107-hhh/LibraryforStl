package com.library.models;

public class TransactionDTO {

	private int bookid;
	private int stdid;
	private int issuerid;
	
	public int getIssuerid() {
		return issuerid;
	}
	public void setIssuerid(int issuerid) {
		this.issuerid = issuerid;
	}
	public int getBookid() {
		return bookid;
	}
	public void setBookid(int bookid) {
		this.bookid = bookid;
	}
	public int getStdid() {
		return stdid;
	}
	public void setStdid(int stdid) {
		this.stdid = stdid;
	}
	
	
}
