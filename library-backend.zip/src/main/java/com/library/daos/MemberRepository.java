package com.library.daos;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.library.entities.Member;

@Repository
public interface MemberRepository extends JpaRepository<Member, Integer> {

}
