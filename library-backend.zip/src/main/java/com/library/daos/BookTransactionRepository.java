package com.library.daos;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.library.entities.Book;
import com.library.entities.BookTransaction;

@Repository
public interface BookTransactionRepository extends JpaRepository<BookTransaction, Integer> {
	@Query(value = "select book from BookTransaction where member_id=?1 and isreturned=0")
	List<Book> findIssueBook(int stdid);
	
	@Query(value = "from BookTransaction where member_id=?1 and isreturned=0")
	List<BookTransaction> findIssueBookTransactions(int stdid);
	
	@Query(value = "select * from BookTransaction where book_id=?1 and member_id=?2 order by id desc limit 1",nativeQuery = true)
	BookTransaction findByBookIdAndMemberId(int bookid,int memid);
	
	List<BookTransaction> findByMemberIdOrderByIdDesc(int id);
	
	List<BookTransaction> findByBookIdOrderByIdDesc(int id);
}
