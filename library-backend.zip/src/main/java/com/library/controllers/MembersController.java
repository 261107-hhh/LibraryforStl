package com.library.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.library.entities.Member;
import com.library.models.MemberDTO;
import com.library.models.Response;
import com.library.services.MemberService;
import com.library.services.UserService;

@CrossOrigin
@RestController
@RequestMapping("/api/members")
public class MembersController {

	@Autowired MemberService mservice;
	@Autowired UserService uservice;
	
	@PostMapping
	public ResponseEntity<?> save(@RequestBody MemberDTO dto) {
		String id=mservice.saveMember(dto);
		return Response.success(id);
	}
	
	@GetMapping
	public ResponseEntity<?> allMembers() {
		return Response.success(mservice.listAll());
	}
	
	@GetMapping("{id}")
	public ResponseEntity<?> findMemberDetails(@PathVariable("id")int id) {
		Member result = mservice.findById(id);
		return Response.success(result);
	}
		
}
