package com.library.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.library.entities.Book;
import com.library.models.Response;
import com.library.models.TransactionDTO;
import com.library.services.BookService;
import com.library.services.TransactionService;

@CrossOrigin
@RestController
@RequestMapping("/api/books")
public class BooksController {

	@Autowired private BookService bservice;
	@Autowired private TransactionService tservice;
	
	@PostMapping
	public ResponseEntity<?> save(@RequestBody Book book) {
		bservice.saveBook(book);
		return Response.success("Book saved");
	}
	
	@PutMapping("{id}")
	public ResponseEntity<?> updateBookDetails(@PathVariable("id")int id,@RequestBody Book book) {
		bservice.updateBook(id, book);
		return Response.success("Book updated");
	}
	
	@GetMapping
	public ResponseEntity<?> allBooks() {
		return Response.success(bservice.listAll());
	}
	
	@GetMapping("{id}")
	public ResponseEntity<?> findBookDetails(@PathVariable("id")int id) {
		return Response.success(bservice.findById(id));
	}
	
	@DeleteMapping("{id}")
	public ResponseEntity<?> deleteBookDetails(@PathVariable("id")int id) {
		bservice.deleteBook(id);
		return Response.success("Deleted successfully");
	}
	
	@GetMapping("history/{id}")
	public ResponseEntity<?> findBookHistory(@PathVariable("id")int id) {
		return Response.success(tservice.bookHistory(id));
	}
	
	@GetMapping("member/{id}")
	public ResponseEntity<?> findMemberHistory(@PathVariable("id")int id) {
		return Response.success(tservice.memberHistory(id));
	}
	
	@PostMapping("issue")
	public ResponseEntity<?> issueBook(@RequestBody TransactionDTO book) {
		tservice.issuebook(book);
		return Response.success("Book issued");
	}
	
	@PostMapping("return")
	public ResponseEntity<?> returnBook(@RequestBody TransactionDTO book) {
		tservice.returnbook(book);
		return Response.success("Book returned");
	}
		
}
