package com.library.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.library.entities.Staff;
import com.library.models.Response;
import com.library.models.StaffDTO;
import com.library.services.StaffService;
import com.library.services.UserService;

@CrossOrigin
@RestController
@RequestMapping("/api/staffs")
public class StaffsController {

	@Autowired StaffService sservice;
	@Autowired UserService uservice;
	
	@PostMapping
	public ResponseEntity<?> save(@RequestBody StaffDTO dto) {
		String id=sservice.saveStaff(dto);
		return Response.success(id);
	}
	
	@GetMapping("{id}")
	public ResponseEntity<?> findMemberDetails(@PathVariable("id")int id) {
		Staff result = sservice.findById(id);
		return Response.success(result);
	}
		
}
