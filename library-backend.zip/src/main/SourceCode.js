"use strict";
/* eslint-disable @typescript-eslint/no-namespace */
Object.defineProperty(exports, "__esModule", { value: true });
exports.SourceCode = void 0;
const eslint_1 = require("eslint");
class SourceCode extends eslint_1.SourceCode {
}
exports.SourceCode = SourceCode;
//# sourceMappingURL=SourceCode.js.map